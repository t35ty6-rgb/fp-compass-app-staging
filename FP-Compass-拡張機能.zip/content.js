// content.js: FP Compass タブ に 注入
// 責務: 拡張存在の告知 / 顧客arming の 中継 / 録音blob の 受け渡し

(function announce() {
  const marker = document.createElement('meta');
  marker.name = 'fp-compass-tab-recorder';
  marker.content = chrome.runtime.getManifest().version;
  document.documentElement.appendChild(marker);
  const s = document.createElement('script');
  s.textContent = 'window.__fpTabRecorder = ' + JSON.stringify(chrome.runtime.getManifest().version) + ';';
  (document.head || document.documentElement).appendChild(s);
  s.remove();
})();

// 拡張 → ページ: 録音完了 blob + イベント を postMessage
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'FP_RECORDING_DONE') {
    window.postMessage({ source: 'fp-tab-recorder', type: 'RECORDING_DONE', payload: msg.payload }, '*');
  }
  if (msg?.type === 'FP_RECORDING_STARTED') {
    window.postMessage({ source: 'fp-tab-recorder', type: 'RECORDING_STARTED', payload: msg.payload }, '*');
  }
});

// ページ → 拡張: arm / disarm / recording トリガー
window.addEventListener('message', async (ev) => {
  if (ev.source !== window) return;
  const data = ev.data;
  if (!data || data.source !== 'fp-compass') return;

  if (data.type === 'ARM_TAB_RECORDER') {
    // FP Compass 顧客カルテで 「録音準備」 ボタン 押下 時
    const r = await chrome.runtime.sendMessage({
      type: 'ARM_RECORDING',
      clientId: data.clientId,
      clientName: data.clientName,
      tenantId: data.tenantId,
    });
    window.postMessage({ source: 'fp-tab-recorder', type: 'ARM_RESULT', payload: r }, '*');
    return;
  }

  if (data.type === 'DISARM_TAB_RECORDER') {
    const r = await chrome.runtime.sendMessage({ type: 'DISARM_RECORDING' });
    window.postMessage({ source: 'fp-tab-recorder', type: 'DISARM_RESULT', payload: r }, '*');
    return;
  }

  if (data.type === 'REQUEST_STOP_TAB_RECORDING') {
    const r = await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
    window.postMessage({ source: 'fp-tab-recorder', type: 'STOP_RESULT', payload: r }, '*');
    return;
  }

  if (data.type === 'GET_TAB_RECORDER_STATE') {
    const r = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
    window.postMessage({ source: 'fp-tab-recorder', type: 'STATE', payload: r }, '*');
    return;
  }

  if (data.type === 'PING_TAB_RECORDER') {
    window.postMessage({ source: 'fp-tab-recorder', type: 'PONG', payload: { version: chrome.runtime.getManifest().version } }, '*');
    return;
  }
});
