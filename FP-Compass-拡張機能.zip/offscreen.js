// offscreen: tabCapture (Zoom タブ音声) + getUserMedia (Mac マイク) を Web Audio API で 合成、 MediaRecorder で 収録

let state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };

async function start(streamId, meta) {
  try {
    // 1) タブ音声 (相手 の 声、 zoom 音)
    const tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId },
      },
      video: false,
    });
    state.tabStream = tabStream;

    // タブ音声 を そのまま スピーカー にも 流す (owner が Zoom で 相手 の 声 を 聞ける よう)
    const passthrough = new Audio();
    passthrough.srcObject = tabStream;
    passthrough.play().catch(() => {});

    // 2) マイク音声 (owner 自身 の 声)
    let micStream = null;
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: {
        echoCancellation: true, noiseSuppression: true, autoGainControl: true,
      }});
      state.micStream = micStream;
    } catch (e) {
      console.warn('mic 拒否 or 取得 失敗、 タブ音声 のみ 記録', e);
    }

    // 3) 合成: AudioContext で 2ソース を 混ぜて 1本 の Stream に
    const ac = new AudioContext();
    state.ac = ac;
    const dest = ac.createMediaStreamDestination();
    ac.createMediaStreamSource(tabStream).connect(dest);
    if (micStream) ac.createMediaStreamSource(micStream).connect(dest);

    // 4) MediaRecorder で 収録
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' :
                 MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '';
    const rec = new MediaRecorder(dest.stream, { mimeType: mime || undefined, audioBitsPerSecond: 96000 });
    state.rec = rec;
    state.chunks = [];
    rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) state.chunks.push(ev.data); };
    rec.onstop = async () => {
      const blob = new Blob(state.chunks, { type: mime || 'audio/webm' });
      const b64 = await blobToBase64(blob);
      chrome.runtime.sendMessage({
        target: 'background', type: 'RECORDING_DONE',
        payload: {
          mime: mime || 'audio/webm',
          size: blob.size,
          durationMs: Date.now() - (state.startedAt || 0),
          base64: b64,
          meta: state.meta || {},
        }
      });
      // クリーンアップ
      try { tabStream.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { micStream?.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { ac.close(); } catch(_) {}
      state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };
    };
    state.meta = meta;
    state.startedAt = Date.now();
    rec.start(1000);
    return { ok: true };
  } catch (e) {
    console.error('start err', e);
    return { ok: false, error: e.message || String(e) };
  }
}

function stop() {
  if (!state.rec || state.stopping) return { ok: false, error: '録音中 で ありません' };
  state.stopping = true;
  try { state.rec.stop(); } catch (e) { return { ok: false, error: e.message }; }
  return { ok: true };
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen') return;
  (async () => {
    if (msg.type === 'START') sendResponse(await start(msg.streamId, msg.meta));
    else if (msg.type === 'STOP') sendResponse(stop());
    else sendResponse({ ok: false, error: 'unknown' });
  })();
  return true;
});
