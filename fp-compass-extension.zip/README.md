# FP Compass 議事録レコーダー (Chrome拡張)

Zoom Web版 の タブ音声 + Mac マイク を 合成 録音 → FP Compass に 自動 送信。 BlackHole 不要。

## install (unpacked)

1. Chrome で `chrome://extensions/` を 開く
2. 右上 「デベロッパー モード」 ON
3. 「パッケージ 化 されて いない 拡張機能 を 読み込む」 クリック
4. このフォルダ `~/.skeleton-fp-compass-chrome-ext/` を 選択
5. 拡張 が 一覧 に 出れば OK

## 使い方

1. Zoom Web版 (zoom.us) を **別 タブ で 開く** ← Zoom アプリ ではなく Web版 が 必要
2. 面談 開始 → owner 側 拡張 アイコン クリック → 「Zoom タブ 録音 を 開始」
3. Chrome の 「タブ 音声 の 共有」 ダイアログ で **該当 Zoom タブ を 選択**
4. 面談 終了 → 拡張 popup で 「録音 を 停止」
5. FP Compass タブ が 自動で 音声 を 受信 → Whisper に 送信 → 議事録 生成

## 仕組み

- **Chrome tabCapture API** で Zoom タブ の 音声 stream を 取得
- **navigator.mediaDevices.getUserMedia** で Mac マイク の 音声 を 取得
- Web Audio API の AudioContext で 2 stream を 合成
- MediaRecorder で webm/opus に 収録 → base64 → content script 経由 で FP Compass に 送信

## 権限 (manifest.json)

- `tabCapture` — Zoom タブ の 音声 取得
- `activeTab` — active タブ の URL 取得
- `offscreen` — MediaRecorder を 動かす offscreen document 用
- `storage` — 設定 保存 (未使用、 将来 用)
- host: `app.skeleton-inc.jp`, `stg.app.skeleton-inc.jp`, `*.zoom.us`, `*.zoom.com`

## FP Compass 側 の 対応

`window.__fpTabRecorder` に 拡張 の version が 入る → 存在 検知 して 「Zoom タブ 録音 モード」 CTA を 出す。 未 install の 場合 は BlackHole ガイド に フォールバック。
