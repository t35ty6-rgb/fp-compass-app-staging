// mainworld.js — MAIN world で 直接 実行 (CSP script-src 'self' の 対象外)
// content.js の meta tag 経由 で 拡張 version を 取得 → window.__fpTabRecorder に set
// これで app.js の if (window.__fpTabRecorder) 検知 が 発火
(function () {
  const meta = document.querySelector('meta[name="fp-compass-tab-recorder"]');
  if (meta && meta.content) {
    window.__fpTabRecorder = meta.content;
    // 拡張検知 イベント (app.js が listen 可能)
    try {
      window.dispatchEvent(new CustomEvent('fp-tab-recorder-ready', { detail: { version: meta.content } }));
    } catch (_) {}
  }
})();
