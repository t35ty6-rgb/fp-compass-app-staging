// offscreen: tabCapture (Zoom タブ音声) + getUserMedia (Mac マイク) を Web Audio API で 合成、 MediaRecorder で 収録
// v1.5.3: AirPods tab音声収録 fix + streamId 失効チェック + rec.onstop await 追加 (qa-reviewer 指摘 修正済)

let state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };

async function loadMicConfig() {
  try {
    const { preferredMicDeviceId, preferredMicIsBluetooth, preferredMicLabel } = await chrome.storage.local.get([
      'preferredMicDeviceId', 'preferredMicIsBluetooth', 'preferredMicLabel'
    ]);
    return { deviceId: preferredMicDeviceId, isBluetooth: !!preferredMicIsBluetooth, label: preferredMicLabel };
  } catch (_) {
    return { deviceId: null, isBluetooth: false, label: null };
  }
}

function buildMicConstraints(cfg) {
  const audio = {};
  if (cfg.deviceId) {
    audio.deviceId = { exact: cfg.deviceId };
  }
  if (cfg.isBluetooth) {
    // Bluetooth: HFP 切替 を 促す 最小構成 (echoCancel系 true だと macOS が HFP に 切替えない ケース あり)
    audio.echoCancellation = false;
    audio.noiseSuppression = false;
    audio.autoGainControl = false;
    audio.channelCount = 1;
    audio.sampleRate = 16000;
  } else {
    audio.echoCancellation = true;
    audio.noiseSuppression = true;
    audio.autoGainControl = true;
  }
  return { audio, video: false };
}

async function acquireMic() {
  const cfg = await loadMicConfig();
  console.log('[offscreen] mic config:', cfg);

  if (cfg.deviceId) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(buildMicConstraints(cfg));
      const track = stream.getAudioTracks()[0];
      console.log('[offscreen] mic acquired (preferred):', track.label, track.getSettings());
      return { stream, cfg, source: 'preferred' };
    } catch (e) {
      console.warn('[offscreen] preferred mic failed, fallback:', e.message);
    }
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false,
    });
    const track = stream.getAudioTracks()[0];
    console.log('[offscreen] mic acquired (default):', track.label, track.getSettings());
    return { stream, cfg: { ...cfg, deviceId: null }, source: 'default' };
  } catch (e) {
    console.warn('[offscreen] mic 完全 不可:', e.message);
    return { stream: null, cfg, source: 'none', error: e };
  }
}

async function verifyMicHasAudio(stream, timeoutMs = 800) {
  // offscreen document は non-visible なので rAF が throttle される → setInterval で 50ms sample
  return new Promise(resolve => {
    try {
      const ac = new AudioContext();
      const src = ac.createMediaStreamSource(stream);
      const analyser = ac.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      let maxLevel = 0;
      const start = Date.now();
      const intervalId = setInterval(() => {
        analyser.getByteTimeDomainData(data);
        for (let i = 0; i < data.length; i++) {
          const v = Math.abs(data[i] - 128);
          if (v > maxLevel) maxLevel = v;
        }
        if (Date.now() - start > timeoutMs) {
          clearInterval(intervalId);
          try { ac.close(); } catch (_) {}
          resolve(maxLevel > 0);
        }
      }, 50);
    } catch (e) {
      resolve(true);
    }
  });
}

async function start(streamId, meta, streamIdIssuedAt) {
  try {
    // v1.5.2 順序: マイク先取り(HFP切替) → 安定待ち → tab取得 の順に変更
    // 旧順序(tab → mic)だと HFP切替後に tabStream が A2DP セッションのまま固まり相手の声が無音になる

    // 1) マイク を 先 に 確保 (HFP 切替 を 先 に 完了 させる)
    let micStream = null;
    let micInfo = { source: 'none', label: null, isBluetooth: false, verifiedAudio: false };
    const micResult = await acquireMic();
    if (micResult.stream) {
      micStream = micResult.stream;
      state.micStream = micStream;
      const track = micStream.getAudioTracks()[0];
      micInfo.source = micResult.source;
      micInfo.label = track.label;
      micInfo.isBluetooth = micResult.cfg.isBluetooth;
    }

    // 2) Bluetooth の 場合 は HFP 切替 安定 待ち (300ms)
    if (micInfo.isBluetooth) {
      await new Promise(r => setTimeout(r, 300));
    }

    // streamId 失効 チェック (getMediaStreamId から 4.2秒 超 で tabCapture 失敗 するため 早期エラー)
    if (streamIdIssuedAt && Date.now() - streamIdIssuedAt > 4200) {
      throw new Error('streamId 失効: マイク取得に時間がかかりすぎました。もう一度録音ボタンを押してください');
    }

    // 3) タブ音声 (HFP 確立後 に キャプチャ)
    const tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId },
      },
      video: false,
    });
    state.tabStream = tabStream;

    // 4) AudioContext 合成 + passthrough
    // passthrough は HTMLAudioElement.srcObject ではなく ac.destination 経由 に変更
    // → 旧方式 は tabStream を AudioElement と AudioContext が 競合使用 → HFP 時 tab 音声 消失 の 原因
    const ac = new AudioContext();
    state.ac = ac;
    if (ac.state === 'suspended') await ac.resume().catch(() => {});

    const dest = ac.createMediaStreamDestination();
    const tabSource = ac.createMediaStreamSource(tabStream);
    tabSource.connect(dest);           // → 録音 へ
    tabSource.connect(ac.destination); // → スピーカー passthrough (相手の声 が 聞こえる)

    if (micStream) ac.createMediaStreamSource(micStream).connect(dest);

    // 5) 音声 検証
    if (micResult.stream) {
      micInfo.verifiedAudio = await verifyMicHasAudio(micStream);
      if (!micInfo.verifiedAudio) {
        console.warn('[offscreen] mic 無音 stream (HFP 切替 失敗 疑い)');
        chrome.runtime.sendMessage({
          target: 'background', type: 'MIC_WARNING',
          payload: { reason: 'silent_stream', label: micInfo.label }
        }).catch(() => {});
      }
    } else {
      chrome.runtime.sendMessage({
        target: 'background', type: 'MIC_WARNING',
        payload: { reason: 'unavailable', error: micResult.error?.message }
      }).catch(() => {});
    }

    // tab 音声 無音 チェック: Bluetooth のみ実行 (非BT は 1200ms 遅延 不要)
    const tabHasAudio = micInfo.isBluetooth ? await verifyMicHasAudio(tabStream, 1200) : true;
    if (!tabHasAudio) {
      console.warn('[offscreen] tab 音声 無音 (Zoom の 相手 が 無音 or tab capture 失敗)');
      chrome.runtime.sendMessage({
        target: 'background', type: 'MIC_WARNING',
        payload: { reason: 'tab_silent', label: 'tab_capture' }
      }).catch(() => {});
    }

    // 6) MediaRecorder で 収録
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' :
                 MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '';
    const rec = new MediaRecorder(dest.stream, { mimeType: mime || undefined, audioBitsPerSecond: 96000 });
    state.rec = rec;
    state.chunks = [];
    rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) state.chunks.push(ev.data); };
    rec.onstop = async () => {
      const blob = new Blob(state.chunks, { type: mime || 'audio/webm' });
      const b64 = await blobToBase64(blob);
      await chrome.runtime.sendMessage({
        target: 'background', type: 'RECORDING_DONE',
        payload: {
          mime: mime || 'audio/webm',
          size: blob.size,
          durationMs: Date.now() - (state.startedAt || 0),
          base64: b64,
          meta: state.meta || {},
          micInfo: state.micInfo || {},
        }
      }).catch(() => {});
      try { tabStream.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { micStream?.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { ac.close(); } catch(_) {}
      state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };
    };
    state.meta = meta;
    state.micInfo = micInfo;
    state.startedAt = Date.now();
    rec.start(1000);
    return { ok: true, micInfo };
  } catch (e) {
    console.error('start err', e);
    return { ok: false, error: e.message || String(e) };
  }
}

function stop() {
  if (!state.rec || state.stopping) return { ok: false, error: '録音中 で ありません' };
  state.stopping = true;
  try { state.rec.stop(); } catch (e) { return { ok: false, error: e.message }; }
  return { ok: true };
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen') return;
  (async () => {
    if (msg.type === 'START') sendResponse(await start(msg.streamId, msg.meta, msg.streamIdIssuedAt));
    else if (msg.type === 'STOP') sendResponse(stop());
    else sendResponse({ ok: false, error: 'unknown' });
  })();
  return true;
});
