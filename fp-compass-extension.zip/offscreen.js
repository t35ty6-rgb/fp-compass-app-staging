// offscreen: tabCapture (Zoom タブ音声) + getUserMedia (Mac マイク) を Web Audio API で 合成、 MediaRecorder で 収録
// v1.5.3: AirPods tab音声収録 fix + streamId 失効チェック + rec.onstop await 追加 (qa-reviewer 指摘 修正済)

let state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };

async function loadMicConfig() {
  try {
    const { preferredMicDeviceId, preferredMicIsBluetooth, preferredMicLabel } = await chrome.storage.local.get([
      'preferredMicDeviceId', 'preferredMicIsBluetooth', 'preferredMicLabel'
    ]);
    return { deviceId: preferredMicDeviceId, isBluetooth: !!preferredMicIsBluetooth, label: preferredMicLabel };
  } catch (_) {
    return { deviceId: null, isBluetooth: false, label: null };
  }
}

function buildMicConstraints(cfg) {
  const audio = {};
  if (cfg.deviceId) {
    audio.deviceId = { exact: cfg.deviceId };
  }
  if (cfg.isBluetooth) {
    // Bluetooth: HFP 切替 を 促す 最小構成 (echoCancel系 true だと macOS が HFP に 切替えない ケース あり)
    audio.echoCancellation = false;
    audio.noiseSuppression = false;
    audio.autoGainControl = false;
    audio.channelCount = 1;
    audio.sampleRate = 16000;
  } else {
    audio.echoCancellation = true;
    audio.noiseSuppression = true;
    audio.autoGainControl = true;
  }
  return { audio, video: false };
}

// v1.5.5 (2026-07-28): AirPods 音声 が 議事録 に 入らない 事故 postmortem
// 原因: v1.5.1 の Bluetooth constraints は setup.html ウィザード を owner が
// 完了 する 前提 だったが、 FP Compass に 促進 UI なし → owner ウィザード 通らず
// preferredMicDeviceId=null → 非BT constraints (echoCancel:true) で getUserMedia
// → macOS が HFP 切替 拒否 → AirPods mic 無音、 の 構造 が 累犯 だった。
// 恒久 fix: setup 抜き で enumerateDevices から BT device を 自動検出 → 自動保存。
function isBluetoothLabel(label) {
  return /airpods|bluetooth|beats|bose|sony wf|sony wh|pixel buds|galaxy buds|jbl|jabra/i.test(String(label || ''));
}

async function autoDetectAndSaveBTDevice() {
  // enumerateDevices の label は getUserMedia 経由 で 一度 権限 通す まで 空文字
  let bootstrap = null;
  try {
    bootstrap = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  } catch (e) {
    console.warn('[offscreen] bootstrap getUserMedia fail (mic permission?):', e.message);
    return null;
  }
  try { bootstrap.getTracks().forEach(t => t.stop()); } catch (_) {}
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const audioIns = devices.filter(d => d.kind === 'audioinput' && d.deviceId && d.deviceId !== 'default');
    const btDev = audioIns.find(d => isBluetoothLabel(d.label));
    if (btDev) {
      console.log('[offscreen] auto-detected BT device:', btDev.label, btDev.deviceId.slice(0, 8));
      // 保存 (次回 高速化 + setup.html を owner が 開いた 時 の 先行入力)
      try {
        await chrome.storage.local.set({
          preferredMicDeviceId: btDev.deviceId,
          preferredMicLabel: btDev.label,
          preferredMicIsBluetooth: true,
          preferredMicSavedAt: Date.now(),
          preferredMicAutoDetected: true,
        });
      } catch (_) {}
      return { deviceId: btDev.deviceId, label: btDev.label, isBluetooth: true };
    }
  } catch (e) {
    console.warn('[offscreen] enumerateDevices fail:', e.message);
  }
  return null;
}

async function acquireMic() {
  let cfg = await loadMicConfig();
  console.log('[offscreen] mic config:', cfg);

  // Preferred path: setup wizard 完了済 or 前回 auto-detect で 保存済
  if (cfg.deviceId) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(buildMicConstraints(cfg));
      const track = stream.getAudioTracks()[0];
      console.log('[offscreen] mic acquired (preferred):', track.label, track.getSettings());
      return { stream, cfg, source: 'preferred' };
    } catch (e) {
      console.warn('[offscreen] preferred mic failed, fallback:', e.message);
    }
  }

  // v1.5.5: 初回 or 未設定 の 場合、 BT device を 自動検出 して 適用
  const autoBt = await autoDetectAndSaveBTDevice();
  if (autoBt) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(buildMicConstraints(autoBt));
      const track = stream.getAudioTracks()[0];
      console.log('[offscreen] mic acquired (auto-bt):', track.label, track.getSettings());
      return { stream, cfg: autoBt, source: 'auto-bt' };
    } catch (e) {
      console.warn('[offscreen] auto-bt getUserMedia fail, fallback default:', e.message);
    }
  }

  // 最終 fallback: 内蔵mic 想定 の default constraints
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false,
    });
    const track = stream.getAudioTracks()[0];
    console.log('[offscreen] mic acquired (default):', track.label, track.getSettings());
    return { stream, cfg: { ...cfg, deviceId: null }, source: 'default' };
  } catch (e) {
    console.warn('[offscreen] mic 完全 不可:', e.message);
    return { stream: null, cfg, source: 'none', error: e };
  }
}

async function verifyMicHasAudio(stream, timeoutMs = 800) {
  // offscreen document は non-visible なので rAF が throttle される → setInterval で 50ms sample
  return new Promise(resolve => {
    try {
      const ac = new AudioContext();
      const src = ac.createMediaStreamSource(stream);
      const analyser = ac.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      let maxLevel = 0;
      const start = Date.now();
      const intervalId = setInterval(() => {
        analyser.getByteTimeDomainData(data);
        for (let i = 0; i < data.length; i++) {
          const v = Math.abs(data[i] - 128);
          if (v > maxLevel) maxLevel = v;
        }
        if (Date.now() - start > timeoutMs) {
          clearInterval(intervalId);
          try { ac.close(); } catch (_) {}
          resolve(maxLevel > 0);
        }
      }, 50);
    } catch (e) {
      resolve(true);
    }
  });
}

async function start(streamId, meta, streamIdIssuedAt) {
  try {
    // v1.5.2 順序: マイク先取り(HFP切替) → 安定待ち → tab取得 の順に変更
    // 旧順序(tab → mic)だと HFP切替後に tabStream が A2DP セッションのまま固まり相手の声が無音になる

    // 1) マイク を 先 に 確保 (HFP 切替 を 先 に 完了 させる)
    let micStream = null;
    let micInfo = { source: 'none', label: null, isBluetooth: false, verifiedAudio: false };
    const micResult = await acquireMic();
    if (micResult.stream) {
      micStream = micResult.stream;
      state.micStream = micStream;
      const track = micStream.getAudioTracks()[0];
      micInfo.source = micResult.source;
      micInfo.label = track.label;
      micInfo.isBluetooth = micResult.cfg.isBluetooth;
    }

    // 2) Bluetooth の 場合 は HFP 切替 安定 待ち (300ms)
    if (micInfo.isBluetooth) {
      await new Promise(r => setTimeout(r, 300));
    }

    // streamId 失効 チェック (getMediaStreamId から 4.2秒 超 で tabCapture 失敗 するため 早期エラー)
    if (streamIdIssuedAt && Date.now() - streamIdIssuedAt > 4200) {
      throw new Error('streamId 失効: マイク取得に時間がかかりすぎました。もう一度録音ボタンを押してください');
    }

    // 3) タブ音声 (HFP 確立後 に キャプチャ)
    const tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId },
      },
      video: false,
    });
    state.tabStream = tabStream;

    // 4) AudioContext 合成 + passthrough
    // passthrough は HTMLAudioElement.srcObject ではなく ac.destination 経由 に変更
    // → 旧方式 は tabStream を AudioElement と AudioContext が 競合使用 → HFP 時 tab 音声 消失 の 原因
    const ac = new AudioContext();
    state.ac = ac;
    if (ac.state === 'suspended') await ac.resume().catch(() => {});

    const dest = ac.createMediaStreamDestination();
    const tabSource = ac.createMediaStreamSource(tabStream);
    tabSource.connect(dest);           // → 録音 へ
    tabSource.connect(ac.destination); // → スピーカー passthrough (相手の声 が 聞こえる)

    if (micStream) ac.createMediaStreamSource(micStream).connect(dest);

    // 5) 音声 検証
    if (micResult.stream) {
      micInfo.verifiedAudio = await verifyMicHasAudio(micStream);
      if (!micInfo.verifiedAudio) {
        console.warn('[offscreen] mic 無音 stream (HFP 切替 失敗 疑い)');
        chrome.runtime.sendMessage({
          target: 'background', type: 'MIC_WARNING',
          payload: { reason: 'silent_stream', label: micInfo.label }
        }).catch(() => {});
      }
    } else {
      chrome.runtime.sendMessage({
        target: 'background', type: 'MIC_WARNING',
        payload: { reason: 'unavailable', error: micResult.error?.message }
      }).catch(() => {});
    }

    // tab 音声 無音 チェック: Bluetooth のみ実行 (非BT は 1200ms 遅延 不要)
    const tabHasAudio = micInfo.isBluetooth ? await verifyMicHasAudio(tabStream, 1200) : true;
    if (!tabHasAudio) {
      console.warn('[offscreen] tab 音声 無音 (Zoom の 相手 が 無音 or tab capture 失敗)');
      chrome.runtime.sendMessage({
        target: 'background', type: 'MIC_WARNING',
        payload: { reason: 'tab_silent', label: 'tab_capture' }
      }).catch(() => {});
    }

    // 6) MediaRecorder で 収録
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' :
                 MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '';
    const rec = new MediaRecorder(dest.stream, { mimeType: mime || undefined, audioBitsPerSecond: 96000 });
    state.rec = rec;
    state.chunks = [];
    rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) state.chunks.push(ev.data); };
    rec.onstop = async () => {
      const blob = new Blob(state.chunks, { type: mime || 'audio/webm' });
      const b64 = await blobToBase64(blob);
      await chrome.runtime.sendMessage({
        target: 'background', type: 'RECORDING_DONE',
        payload: {
          mime: mime || 'audio/webm',
          size: blob.size,
          durationMs: Date.now() - (state.startedAt || 0),
          base64: b64,
          meta: state.meta || {},
          micInfo: state.micInfo || {},
        }
      }).catch(() => {});
      try { tabStream.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { micStream?.getTracks().forEach(t => t.stop()); } catch(_) {}
      try { ac.close(); } catch(_) {}
      state = { rec: null, chunks: [], stopping: false, tabStream: null, micStream: null, ac: null };
    };
    state.meta = meta;
    state.micInfo = micInfo;
    state.startedAt = Date.now();
    rec.start(1000);
    return { ok: true, micInfo };
  } catch (e) {
    console.error('start err', e);
    return { ok: false, error: e.message || String(e) };
  }
}

function stop() {
  if (!state.rec || state.stopping) return { ok: false, error: '録音中 で ありません' };
  state.stopping = true;
  try { state.rec.stop(); } catch (e) { return { ok: false, error: e.message }; }
  return { ok: true };
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen') return;
  (async () => {
    if (msg.type === 'START') sendResponse(await start(msg.streamId, msg.meta, msg.streamIdIssuedAt));
    else if (msg.type === 'STOP') sendResponse(stop());
    else sendResponse({ ok: false, error: 'unknown' });
  })();
  return true;
});
