// setup.js — マイク設定 ウィザード
// 目的: 客が 1度 これ を 通せば AirPods でも 内蔵mic でも 確実 に mic が 取れる 状態に する

const $ = (id) => document.getElementById(id);

let selectedDeviceId = null;
let selectedDeviceLabel = null;
let selectedIsBluetooth = false;
let audioContext = null;
let analyser = null;
let animFrame = null;

// AirPods / Bluetooth 判定
function isBluetoothDevice(label) {
  return /airpods|bluetooth|beats|bose|sony wf|sony wh|pixel buds|galaxy buds|jbl|jabra/i.test(label || '');
}

function markStepDone(n) {
  $('num-' + n).classList.add('done');
  const next = $('step-' + (n + 1));
  if (next) {
    next.style.opacity = '1';
    next.style.pointerEvents = 'auto';
  }
}

// -------- STEP 1: mic grant --------
$('btn-grant').addEventListener('click', async () => {
  const btn = $('btn-grant');
  const status = $('step-1-status');
  btn.disabled = true;
  btn.textContent = 'Chrome の 許可 プロンプト を 確認…';
  status.innerHTML = '';

  try {
    // Chrome に mic prompt を 出させる (このタブ は visible なので macOS も 素直 に HFP 切替 する)
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    // grant 得た → tracks は 即 stop (この段階 では 録音 しない)
    stream.getTracks().forEach(t => t.stop());
    status.innerHTML = '<div class="success"><b>マイクが 許可されました。</b> STEP 2 に 進んでください。</div>';
    btn.textContent = '✓ 許可 済み';
    markStepDone(1);
    await loadDevices();
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'もう 一度 試す';
    if (e.name === 'NotAllowedError') {
      status.innerHTML = '<div class="danger"><b>マイク が ブロック されて います。</b> Chrome の アドレス バー 左端 の 錠マーク を クリック → 「マイク」 を 「許可」 に して ページ を 再読み込み して ください。</div>';
    } else {
      status.innerHTML = '<div class="danger"><b>エラー:</b> ' + (e.message || e.name) + '</div>';
    }
  }
});

// -------- STEP 2: device selection --------
async function loadDevices() {
  const list = $('device-list');
  list.innerHTML = '<p style="color:var(--dim);font-size:13px;">デバイス 一覧 を 取得 中…</p>';

  const devices = await navigator.mediaDevices.enumerateDevices();
  const inputs = devices.filter(d => d.kind === 'audioinput' && d.deviceId && d.deviceId !== 'default' && d.deviceId !== 'communications');

  if (inputs.length === 0) {
    list.innerHTML = '<div class="danger"><b>マイク が 見つかりません。</b> Mac の <a href="#" style="color:#B91C1C;font-weight:800;">システム設定 → プライバシー と セキュリティ → マイク</a> で Google Chrome の トグル が ON か 確認 して ください。</div>';
    return;
  }

  // 前回 の 選択 を 復元
  const { preferredMicDeviceId } = await chrome.storage.local.get('preferredMicDeviceId');

  list.innerHTML = '';
  inputs.forEach((d, idx) => {
    const isBt = isBluetoothDevice(d.label);
    const isSelected = preferredMicDeviceId === d.deviceId || (!preferredMicDeviceId && idx === 0);
    if (isSelected) {
      selectedDeviceId = d.deviceId;
      selectedDeviceLabel = d.label;
      selectedIsBluetooth = isBt;
    }
    const div = document.createElement('label');
    div.className = 'device' + (isBt ? ' airpods' : '') + (isSelected ? ' selected' : '');
    div.innerHTML = `
      <input type="radio" name="device" value="${d.deviceId}" ${isSelected ? 'checked' : ''}>
      <div class="device-info">
        <div class="device-label">${escapeHtml(d.label || 'マイク デバイス')}</div>
        <div class="device-meta">${d.deviceId.slice(0, 24)}…</div>
      </div>
    `;
    div.querySelector('input').addEventListener('change', () => {
      selectedDeviceId = d.deviceId;
      selectedDeviceLabel = d.label;
      selectedIsBluetooth = isBt;
      document.querySelectorAll('.device').forEach(el => el.classList.remove('selected'));
      div.classList.add('selected');
      updateAirpodsWarn();
    });
    list.appendChild(div);
  });

  updateAirpodsWarn();
  await saveSelection();
  markStepDone(2);
}

function updateAirpodsWarn() {
  const warn = $('airpods-warn');
  if (selectedIsBluetooth) {
    warn.innerHTML = '<div class="warn"><b>Bluetooth デバイス を 選択 中。</b> AirPods 系 は Zoom を <b>ブラウザ 版</b> で 開き、 <b>拡張 で 録音 開始 する 前 に AirPods を 接続</b> して ください。 録音中 に AirPods を 外す と mic 切替 で 途切れる 場合 が あります。</div>';
  } else {
    warn.innerHTML = '';
  }
}

async function saveSelection() {
  await chrome.storage.local.set({
    preferredMicDeviceId: selectedDeviceId,
    preferredMicLabel: selectedDeviceLabel,
    preferredMicIsBluetooth: selectedIsBluetooth,
    preferredMicSavedAt: Date.now(),
  });
}

// -------- STEP 3: test recording --------
$('btn-test').addEventListener('click', async () => {
  const btn = $('btn-test');
  const result = $('test-result');
  const levelBar = $('level-bar');

  await saveSelection();

  btn.disabled = true;
  btn.textContent = '準備中…';
  result.innerHTML = '';

  try {
    // AirPods 用 の 制約 (HFP 切替 を 促す)
    const constraints = buildConstraints(selectedDeviceId, selectedIsBluetooth);
    const stream = await navigator.mediaDevices.getUserMedia(constraints);

    // 実際 に 取れた settings を 確認
    const track = stream.getAudioTracks()[0];
    const settings = track.getSettings();
    console.log('[setup] actual settings:', settings);

    // Level meter
    audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(stream);
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);
    function tick() {
      analyser.getByteFrequencyData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i];
      const avg = sum / data.length;
      levelBar.style.width = Math.min(100, avg / 128 * 100) + '%';
      animFrame = requestAnimationFrame(tick);
    }
    tick();

    // Record 5 sec
    const chunks = [];
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
    const rec = new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 96000 });
    rec.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };

    btn.textContent = '録音中… (「あー」 と 話してください)';
    let peak = 0;
    const peakInterval = setInterval(() => {
      analyser.getByteFrequencyData(data);
      let sum = 0; for (let i = 0; i < data.length; i++) sum += data[i];
      const avg = sum / data.length;
      if (avg > peak) peak = avg;
    }, 50);

    rec.start(100);
    await new Promise(r => setTimeout(r, 5000));
    rec.stop();
    clearInterval(peakInterval);

    await new Promise(r => rec.onstop = r);

    // Cleanup
    stream.getTracks().forEach(t => t.stop());
    if (animFrame) cancelAnimationFrame(animFrame);
    if (audioContext) { try { audioContext.close(); } catch (_) {} }
    levelBar.style.width = '0%';

    const blob = new Blob(chunks, { type: mime });
    const url = URL.createObjectURL(blob);

    // Result render
    const peakOk = peak > 8;  // 声 が 拾えたか の 目安
    const html = `
      <div class="${peakOk ? 'success' : 'warn'}">
        <b>${peakOk ? '録音 成功。' : '音声 が 弱い or 拾えて ない 可能性 が あります。'}</b><br>
        録音 サイズ: <code>${(blob.size / 1024).toFixed(1)} KB</code>  /
        ピーク: <code>${peak.toFixed(1)}</code>  /
        レート: <code>${settings.sampleRate || '?'} Hz</code>  /
        チャンネル: <code>${settings.channelCount || '?'}</code>
        <br><br>
        <audio controls src="${url}"></audio>
        <br>
        <span style="font-size:12.5px;">再生 して 自分の声 が 聞こえれば 完了 です。 聞こえなければ 別の マイク を 選び直して 再テスト して ください。</span>
      </div>
    `;
    result.innerHTML = html;

    if (peakOk) {
      markStepDone(3);
      btn.textContent = '✓ テスト 完了';
      await chrome.storage.local.set({ micSetupCompletedAt: Date.now() });
    } else {
      btn.disabled = false;
      btn.textContent = 'もう 一度 テスト';
    }
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'もう 一度 テスト';
    result.innerHTML = '<div class="danger"><b>エラー:</b> ' + (e.message || e.name) + '<br>選択 した マイク が 使えません。 別の デバイス を 選んで ください。</div>';
    console.error('[setup] test failed', e);
  }
});

// -------- shared constraint builder --------
// このロジック は offscreen.js からも 参照 する ため storage 経由 で 共有
function buildConstraints(deviceId, isBluetooth) {
  const audio = {};
  if (deviceId) {
    audio.deviceId = { exact: deviceId };
  }
  if (isBluetooth) {
    // AirPods 等 Bluetooth: HFP 切替 を 促す ため 最小構成
    // echoCancellation / noiseSuppression / autoGainControl を true にすると
    // macOS が Chrome 側 の audio graph 優先 で HFP 切替 が 発火 し にくい
    audio.echoCancellation = false;
    audio.noiseSuppression = false;
    audio.autoGainControl = false;
    audio.channelCount = 1;
    audio.sampleRate = 16000; // HFP 標準 sample rate
  } else {
    // 内蔵mic / 有線: 通常の エコー抑制 使う
    audio.echoCancellation = true;
    audio.noiseSuppression = true;
    audio.autoGainControl = true;
  }
  return { audio, video: false };
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ページ 起動時: 既存許可 が あれば デバイス一覧 を 即 出す
(async () => {
  try {
    const perm = await navigator.permissions.query({ name: 'microphone' });
    if (perm.state === 'granted') {
      $('step-1-status').innerHTML = '<div class="success"><b>マイク は 既 に 許可済み。</b></div>';
      $('btn-grant').textContent = '✓ 許可 済み';
      $('btn-grant').disabled = true;
      markStepDone(1);
      await loadDevices();
    }
  } catch (_) { /* permissions API 未対応 の 古い Chrome */ }
})();
