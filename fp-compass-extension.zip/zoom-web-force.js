// zoom-web-force.js v2 (2026-07-18) — Zoom アプリ 起動 阻止 の 強化版
// tabCapture は Zoom Web でしか動かない ので、 Zoom App 起動 を あらゆる 経路 で block

(function () {
  const log = (...a) => console.log('[zoom-web-force]', ...a);

  // ==== 1. zoommtg:// URL の 全 経路 で block ====
  // 1a) window.location.href setter
  try {
    const origSetter = Object.getOwnPropertyDescriptor(window.Location.prototype, 'href')?.set;
    if (origSetter) {
      Object.defineProperty(window.Location.prototype, 'href', {
        set(v) {
          if (typeof v === 'string' && /^zoommtg:/i.test(v)) { log('blocked href set:', v.substring(0, 50)); return; }
          return origSetter.call(this, v);
        },
        configurable: true,
      });
    }
  } catch (e) { log('href intercept failed:', e.message); }

  // 1b) location.assign / replace
  try {
    const origAssign = window.Location.prototype.assign;
    const origReplace = window.Location.prototype.replace;
    window.Location.prototype.assign = function (v) {
      if (typeof v === 'string' && /^zoommtg:/i.test(v)) { log('blocked location.assign'); return; }
      return origAssign.call(this, v);
    };
    window.Location.prototype.replace = function (v) {
      if (typeof v === 'string' && /^zoommtg:/i.test(v)) { log('blocked location.replace'); return; }
      return origReplace.call(this, v);
    };
  } catch (e) { log('assign/replace intercept failed:', e.message); }

  // 1c) window.open
  try {
    const origOpen = window.open;
    window.open = function (url, ...rest) {
      if (typeof url === 'string' && /^zoommtg:/i.test(url)) { log('blocked window.open'); return null; }
      return origOpen.call(this, url, ...rest);
    };
  } catch (e) { log('window.open intercept failed:', e.message); }

  // 1d) <a href="zoommtg://..."> click 阻止 + href を無効化
  const nukeZoomLinks = () => {
    document.querySelectorAll('a[href^="zoommtg:" i], a[href^="zoomus:" i]').forEach(a => {
      a.href = 'javascript:void(0)';
      a.dataset.fpBlocked = '1';
      log('nuked zoommtg link');
    });
  };
  document.addEventListener('click', (e) => {
    const a = e.target.closest?.('a');
    if (a && /^zoommtg:/i.test(a.href || '')) {
      e.preventDefault();
      e.stopPropagation();
      log('blocked click on zoommtg link');
    }
  }, true);

  // 1e) iframe src = zoommtg
  try {
    const origIframeSrcDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
    if (origIframeSrcDesc?.set) {
      Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
        set(v) {
          if (typeof v === 'string' && /^zoommtg:/i.test(v)) { log('blocked iframe.src'); return; }
          return origIframeSrcDesc.set.call(this, v);
        },
        get: origIframeSrcDesc.get,
        configurable: true,
      });
    }
  } catch (e) { log('iframe.src intercept failed:', e.message); }

  // ==== 2. URL 自動 rewrite: /wc/join/{id} 系 → app.zoom.us/wc/{id}/join?fromPWA=1 (Web client 強制) ====
  // fromPWA=1 は Zoom 内部 flag で 「Zoom App 起動 の prompt を skip して Web で 直接開く」
  const url = new URL(window.location.href);
  const isZoomHost = /zoom\.(us|com)$/.test(url.hostname);
  if (isZoomHost) {
    const currentPath = url.pathname;
    // pattern1: /j/{id} → /wc/{id}/join?fromPWA=1
    const m1 = currentPath.match(/^\/j\/(\d+)/);
    // pattern2: /wc/join/{id} → /wc/{id}/join?fromPWA=1
    const m2 = currentPath.match(/^\/wc\/join\/(\d+)/);
    // pattern3: /s/{id} (start URL) → /wc/{id}/start?fromPWA=1
    const m3 = currentPath.match(/^\/s\/(\d+)/);
    if (m1 || m2 || m3) {
      const id = (m1 || m2 || m3)[1];
      const isStart = !!m3;
      const target = `/wc/${id}/${isStart ? 'start' : 'join'}`;
      if (currentPath !== target) {
        url.pathname = target;
        if (!url.searchParams.has('fromPWA')) url.searchParams.set('fromPWA', '1');
        log('rewriting URL to Web client direct:', url.pathname + url.search);
        window.location.replace(url.toString());
        return; // rewrite 後 は 以降 の 処理 skip (ページ 再読み込み で 新 script が 走る)
      }
    }
    // 既に /wc/{id}/join or /wc/{id}/start にいる 場合 も fromPWA=1 追加
    if (/^\/wc\/\d+\/(join|start)/.test(currentPath) && !url.searchParams.has('fromPWA')) {
      url.searchParams.set('fromPWA', '1');
      log('adding fromPWA=1 to existing /wc URL');
      window.location.replace(url.toString());
      return;
    }
  }

  // ==== 3. 「ブラウザで参加」 link auto click + zoommtg link nuke (loop 10秒) ====
  const CLICK_TEXT_PATTERNS = [
    /ブラウザから参加|ブラウザから起動|Web から参加|Join from (Your |the )?Browser|Launch Meeting from Browser|Web ブラウザ で 参加|Join in Browser/i,
  ];
  const tryClickJoin = () => {
    const links = [...document.querySelectorAll('a, button, [role="button"]')];
    for (const el of links) {
      const t = (el.textContent || '').trim();
      if (t && CLICK_TEXT_PATTERNS.some(re => re.test(t)) && el.offsetParent !== null) {
        log('auto-clicking:', t);
        el.click();
        return true;
      }
    }
    return false;
  };

  let attempts = 0;
  const iv = setInterval(() => {
    attempts++;
    if (attempts > 20) { clearInterval(iv); return; }
    nukeZoomLinks();
    if (tryClickJoin()) { clearInterval(iv); return; }
  }, 500);

  // DOM ready 時 に 即 nuke + click 試行
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { nukeZoomLinks(); tryClickJoin(); });
  } else {
    nukeZoomLinks(); tryClickJoin();
  }

  log('v2 initialized on', window.location.href);
})();
